
package recuperatorio;

/**
 *
 * @author Milee // Milena Rodríguez, COM 121, Recuperatorio primer parcial
 */
public class NaveExploracion extends Nave implements Explorar {
    private Mision mision;

    public NaveExploracion(Mision mision, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.mision = mision;
    }
    

    @Override
    public void mostrarInfo() { // método toString
        System.out.println("Nave exploracion, nombre:" + nombre + " , capacidad de tripulacion: " + capacidadTripulacion + " , anio de lanzamiento: " +anioLanzamiento+ " , tipo de mision: " + mision);
    }

    @Override
    public void explorar() {
        System.out.println("La nave de exploracion salio a explorar");
    }
}
