
package recuperatorio;

/**
 *
 * @author Milee // Milena Rodríguez, COM 121, Recuperatorio primer parcial
 */
public class CruceroEstelar extends Nave {
    private int cantidadPasajeros;

    public CruceroEstelar(int cantidadPasajeros, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    
    @Override 
    public void mostrarInfo(){ // método toString
        System.out.println("Crucero estelar, nombre:" + nombre + " , capacidad de tripulacion: " + capacidadTripulacion + " , anio de lanzamiento: " +anioLanzamiento+ " , cantidad pasajeros: " + cantidadPasajeros);
    }
}
