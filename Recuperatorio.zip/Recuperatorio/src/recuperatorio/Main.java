
package recuperatorio;

/**
 *
 * @author Milee // Milena Rodríguez, COM 121, Recuperatorio primer parcial
 */
public class Main {

       public static void main(String[] args) {
        Agencia agencia = new Agencia(); 
        
        try {
            
            agencia.agregarNave(new NaveExploracion(Mision.CARTOGRAFIA,"Nave 1", 1000, 2020));
            agencia.agregarNave(new NaveExploracion(Mision.INVESTIGACION,"Nave 2", 1500, 2023));
            agencia.agregarNave(new NaveExploracion(Mision.CONTACTO,"Nave 3", 1200, 2021));
            
            agencia.agregarNave(new Carguero(300, "Galactica", 100, 2019));
            agencia.agregarNave(new Carguero(100, "Carguero 2", 90, 2004));
            agencia.agregarNave(new Carguero(500, "Carguero 3", 140, 2009));
            
            
            agencia.agregarNave(new CruceroEstelar(305, "Crucero 1", 400, 1980));
            agencia.agregarNave(new CruceroEstelar(345, "Crucero 2", 500, 2020));
            agencia.agregarNave(new CruceroEstelar(380, "Crucero 3", 300, 1890));
            
            
            
            //Se muestran las naves previamente agregadas
            agencia.mostrarNaves(); 
            
            System.out.println("----");
            //Se inicia la exploración
            agencia.iniciarExploracion();
            
            System.out.println("----");
            //Intentar agregar el duplicado para que te de error
            agencia.agregarNave(new Carguero(300, "Galáctica", 100, 2019));
            
            
            //En caso de que se encuentre algún duplicado en las agrecaciones, va a llamar a la función de exception personalizada que se creó previamente
        } catch (NaveExistenteException e) {
            System.out.println("Error: " +e.getMessage());
        }
    }
}
