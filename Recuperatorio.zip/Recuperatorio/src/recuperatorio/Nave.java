
package recuperatorio;

import java.util.Objects;

/**
 *
 * @author Milee // Milena Rodríguez, COM 121, Recuperatorio primer parcial
 */

public abstract class Nave {
    protected String nombre;
    protected int capacidadTripulacion;
    protected int anioLanzamiento;

    public Nave(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    public int getAnioLanzamiento() {
        return anioLanzamiento;
    }
    
    public abstract void mostrarInfo();
    
    
    @Override
    public boolean equals(Object o) {
    if (this == o) {
        return true; 
    }
    if (o == null || o.getClass() != this.getClass()) {
        return false; 
    }
    Nave nave = (Nave) o; // Hacemos el casting
    return nombre.equals(nave.nombre) && anioLanzamiento == nave.anioLanzamiento; // Comparamos los atributos
}

    @Override
    public int hashCode() {
        return Objects.hash(nombre,anioLanzamiento);
    }
}