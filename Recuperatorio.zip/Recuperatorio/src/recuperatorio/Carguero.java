
package recuperatorio;

/**
 *
 * @author Milee // Milena Rodríguez, COM 121, Recuperatorio primer parcial
 */
public class Carguero extends Nave implements Explorar {
    private int capacidadCarga;

    public Carguero(int capacidadCarga, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        if (capacidadCarga < 100 || capacidadCarga > 500) {
            throw new IllegalArgumentException("La capacidad de carga debe estar entre 100 y 500 toneladas.");
        }
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void mostrarInfo() { // método toString
        System.out.println("Carguero, nombre: " + nombre + " , capacidad de tripulacion: " + capacidadTripulacion + " , anio de lanzamiento: " + anioLanzamiento + " , capacidad de carga: " + capacidadCarga);
    }

    public void explorar() {
        System.out.println("El carguero salio a explorar");
    }
}

