
package recuperatorio;

/**
 *
 * @author Milee // Milena Rodríguez, COM 121, Recuperatorio primer parcial
 */
public class NaveExistenteException extends Exception {
    public static final String MESSAGE = "Ya existe esa nave";
    
    public NaveExistenteException(){
        super(MESSAGE);
    }
}
