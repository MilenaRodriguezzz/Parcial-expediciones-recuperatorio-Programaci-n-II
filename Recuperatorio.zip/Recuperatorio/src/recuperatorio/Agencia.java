package recuperatorio;

/**
 *
 * @author Milee // Milena Rodríguez, COM 121, Recuperatorio primer parcial
 */

import java.util.ArrayList;


class Agencia {
    private ArrayList<Nave> naves;
    
    public Agencia(){
        naves = new ArrayList<>();
    }
    
    public void agregarNave(Nave nave) throws NaveExistenteException {
        verificarNave(nave);
        if(nave!=null){
            naves.add(nave);
        }
    }
    
    
    public void mostrarNaves(){
        for(Nave nave: naves){
            nave.mostrarInfo();
        }
    }
    
    public void verificarNave(Nave nave) throws NaveExistenteException{
        if(naves.contains(nave)){
            throw new NaveExistenteException();
        }
    }
    
    public void iniciarExploracion(){
        System.out.println("Se mandaran a explorar las naves");
        for (Nave nave: naves){
            if(nave instanceof Explorar exploracion){
                exploracion.explorar();
            }
            else {
                System.out.println(nave.getNombre() + " no puede participar en misiones porque es un crucero estelar");
            
            }
        }
    }
}

