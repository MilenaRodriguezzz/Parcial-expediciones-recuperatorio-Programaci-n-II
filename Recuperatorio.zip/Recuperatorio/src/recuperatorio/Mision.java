
package recuperatorio;

/**
 *
 * @author Milee // Milena Rodríguez, COM 121, Recuperatorio primer parcial
 */
public enum Mision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO,
}
